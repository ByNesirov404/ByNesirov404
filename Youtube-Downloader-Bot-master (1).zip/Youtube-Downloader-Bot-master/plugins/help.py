from pyrogram import Client, Filters


@Client.on_message(Filters.command(["help"]))
async def start(client, message):
    helptxt = f"Hal-hazırda yalnız Youtube Single-i dəstələyir (Pleylist yoxdur) Sadəcə Youtube Url Göndərin"
    await message.reply_text(helptxt)
